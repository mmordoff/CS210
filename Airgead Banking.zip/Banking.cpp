#include <iostream>
#include <iomanip>
#include <string>

using namespace std;

int main() {
	//declare variables
	float initInv, monDep, AnuInt, months, years, totalAm, intAmt, yearTotInt;

	//Display menu to user
	cout << "******************************" << endl;
	cout << "**********Data Input**********" << endl;
	cout << "Initial Investment Amount: $" << endl;
	cout << "Monthly Deposit: $" << endl;
	cout << "Annual Interest: %" << endl;
	cout << "Number of years: " << endl;

	system("PAUSE");

	//get input from user
	cout << "******************************" << endl;
	cout << "**********Data Input**********" << endl;
	cout << "Initial Investment Amount: $" << endl;
	cin >> initInv;
	if (initInv < 1) {
		cout << "Invalid entry. Please enter a number more than 0"; //checks user input
		cin >> initInv;
	}

	cout << "Monthly Deposit: $" << endl; // can be 0
	cin >> monDep;
	cout << "Annual Interest: %" << endl; //must be more than 0
	cin >> AnuInt;
	if (AnuInt < 1) {
		cout << "Invalid entry. Please enter a number more than 0"; //checks user input
		cin >> AnuInt;
	}

	cout << "Number of years: " << endl;
	cin >> years;
	if (years < 1) {
		cout << "Invalid entry. Please enter a number more than 0"; //checks user input
		cin >> years;
	}

	months = years * 12; // calculates months in a year
	system("PAUSE");

	totalAm = initInv;

	//output no additonal monthly deposits
	cout << "\n Balance and Interest Without Additonal Monthly Deposits\n";
	cout << "================================================================\n";
	cout << "Year\t\tYearEnd Balance\t\tYear End Earned Interest\n";
	cout << "-----------------------------------------------------------------\n";

	//loop for calculations
	for (int i = 0; i < years; i++) {
		//calculate interest amount
		intAmt = (totalAm) * ((AnuInt / 100));
		//calcualte total amount
		totalAm = totalAm + intAmt;

		//output calculations into chart to two decimal places
		cout << (i + 1) << "\t\t$" << fixed << setprecision(2) << totalAm << "\t\t\t$" << intAmt << "\n";
	}

	cout << endl << endl << endl;

	totalAm = initInv;

	//output for additonal monthly deposits
	cout << "\n\nBalance and Interest With Additional Monthly Deposits\n";
	cout << "================================================================\n";
	cout << "Year\t\tYearEnd Balance\t\tYear End Earned Interest\n";
	cout << "-----------------------------------------------------------------\n";

	//loop for calculations
	for (int i = 0; i < years; i++) {
		//set yearly interest to zero at the start of the year
		yearTotInt = 0;
		for (int j = 0; j < 12; j++) {
			//calculate monthly interest
			intAmt = (totalAm + monDep) * ((AnuInt / 100) / 12);
			//caclulate month end interest
			yearTotInt = yearTotInt + intAmt;
			//calculate month end total
			totalAm = totalAm + monDep + intAmt;
		}

		//output results to two decimal places
		cout << (i + 1) << "\t\t$" << fixed << setprecision(2) << totalAm << "\t\t\t$" << yearTotInt << "\n";
	}

	return 0;
}